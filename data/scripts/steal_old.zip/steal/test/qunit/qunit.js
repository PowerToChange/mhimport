steal
  .plugins("funcunit/qunit")
  .css('one','../two')
  .then("steal_test")