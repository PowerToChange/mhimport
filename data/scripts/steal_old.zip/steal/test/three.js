steal(function() {
	order(3)
});