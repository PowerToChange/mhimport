order(1);
steal('../another/two','four','wrong');
//something here
another = function(somevariablename){
    return somevariablename *2;
};