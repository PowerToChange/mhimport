var a = true, b;
if(a){
	b = 1;
} else {
	b = 2;
}
