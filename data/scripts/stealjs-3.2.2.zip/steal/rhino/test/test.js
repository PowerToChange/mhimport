load('steal/rhino/rhino.js');


steal('//steal/rhino/test/file')
