steal("foo/bar",
/**
 * Comment
 * @param {Object} "something/else"
 */
"abc/def").then(function(){
	var f = 0xa;
	var _5 = {a: 1};
	_5.a;
}).then("something/else");

steal("one/two");
