var foo;
steal.dev.log("hi()");