steal("foo/bar",
/**
 * Comment
 * @param {Object} "something/else"
 */
"abc/def").then(function(){
	
}).then("something/else");

steal("one/two");
