function( one, two ) {
	if ( this[i] == isNumber(value) ) {
		while ( a < b ) {}
	}
}