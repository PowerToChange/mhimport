// loads all of steal's command line tests

load('steal/build/test/run.js');

load('steal/build/styles/test/styles_test.js');

load('steal/get/test/get_test.js');

load('steal/clean/test/clean_test.js');

load('steal/generate/test/run.js');

load('steal/less/test/less_test.js');

load('steal/coffee/coffee_build_test.js');