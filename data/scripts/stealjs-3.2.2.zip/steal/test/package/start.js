steal("//steal/test/package/package").then(function(){
	console.log("loaded ...")
})
