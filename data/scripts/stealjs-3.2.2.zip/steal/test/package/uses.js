steal("steal/test/package/1.js").then(function(){
	packagesStolen.push("uses");
})
