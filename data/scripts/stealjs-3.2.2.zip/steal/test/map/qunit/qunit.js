steal
  .then("funcunit/qunit", "steal/test/map")
  .then("./map_test.js")
