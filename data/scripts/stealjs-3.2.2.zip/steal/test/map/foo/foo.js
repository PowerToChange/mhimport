steal('foo2')
	.then(function(){
		foo = true;
	})