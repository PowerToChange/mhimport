steal("funcunit/qunit", "steal/test/multiple")
  .then("multiple_test")
