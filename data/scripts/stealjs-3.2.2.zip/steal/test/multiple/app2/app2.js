steal('zoo')
