steal.then('//steal/test/files/loadDuplicate', '//steal/test/files/duplicate',function(){
	
})