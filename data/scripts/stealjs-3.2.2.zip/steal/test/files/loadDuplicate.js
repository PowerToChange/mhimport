steal.then("//steal/test/files/duplicate.js").then(function(){
	
})
