PLUGINLOADED = true;
steal("./dependency.js")
