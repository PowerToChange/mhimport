ORDER.push(2)
steal(function(){
	ORDER.push("then2")
})
