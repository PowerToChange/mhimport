steal('steal/coffee')
	.then('./coffee.coffee')
