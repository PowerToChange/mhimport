$.holdReady(true);
steal.client.trigger("clientloaded");